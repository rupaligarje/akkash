package com.example.photoquiz;
import com.example.funchem.R;

import android.app.Activity;
	import android.content.Intent;
	import android.os.Bundle;
	import android.view.View;
	import android.widget.Button;
import android.widget.TextView;

public class Que4 extends Activity {
	
		TextView tvRes;
		int answer;
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			// TODO Auto-generated method stub
			super.onCreate(savedInstanceState);
			setContentView(R.layout.que4);
			Button rb1, rb2, rb3, rb4,rb5;
			answer = 3;

			rb1 = (Button) findViewById(R.id.rd401);
			rb2 = (Button) findViewById(R.id.rd402);
			rb3 = (Button) findViewById(R.id.rd403);
			rb4 = (Button) findViewById(R.id.rd404);
			tvRes = (TextView) findViewById(R.id.tvr4);
			rb5 = (Button) findViewById(R.id.bn4);
			rb1.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
						tvRes.setText("Wrong");

				}
			});
			rb2.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
						tvRes.setText("Correct");

				}
			});
			rb3.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
				
						tvRes.setText("Wrong");
					

				}
			});
			rb4.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
						tvRes.setText("Wrong");

				}
			});
			rb5.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent opennextActivity = new Intent("com.example.funchem.QUE5");
					startActivity(opennextActivity);
				}
			});
		}
		
		
	}



