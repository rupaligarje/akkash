
public class Que3 {

}
