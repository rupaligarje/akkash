README
========
This is an android project.
--------------------------
This project contains photoquiz.apk.

Prerequisites
-------------
android OS

How to use
----------
download photoquiz.apk on android and install it. 
